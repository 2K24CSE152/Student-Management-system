# CampusFlow Student Management System

A Flask-based starter application for student records, courses, attendance, grades, fee payments, staff accounts, dashboard statistics and CSV export.

## Included features

- Login and password hashing
- Role-based access: administrator and teacher
- Student directory, search, create/edit and archive/restore
- Course catalogue and course deletion safeguards
- Daily attendance entry (one entry per student/date; later submissions update the entry)
- Assessment/grade recording and percentage calculation
- Fee payment ledger and payment history
- Staff account creation and account enable/disable
- Student CSV export
- Responsive UI with light/dark theme
- SQLite for local setup; MySQL supported through `DATABASE_URL`

## Run locally on Windows

1. Install Python 3.10 or newer.
2. Extract the project ZIP and open the project folder in VS Code or PyCharm.
3. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

4. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

5. Copy `.env.example` to `.env`. Set a unique `SECRET_KEY`. For local use, SQLite is already configured.
6. Start the app:

   ```powershell
   python app.py
   ```

7. Open `http://127.0.0.1:5000`.

On first startup, the app creates the database and a default administrator:
- Username: `admin`
- Password: `ChangeMe123!`

**Change this password before using real data.** For initial admin setup, set `INITIAL_ADMIN_PASSWORD` in the environment before the first run. If the database has already been created, changing this environment variable does not change the existing account password; implement a password-change/reset flow before client deployment.

## MySQL configuration

Create a database and a dedicated database user in MySQL, then set `DATABASE_URL` in `.env`:

```env
DATABASE_URL=mysql+pymysql://school_user:your_encoded_password@127.0.0.1:3306/student_management
SECRET_KEY=use-a-long-random-secret
```

URL-encode special characters in the database password. Ensure the MySQL user has privileges only on this application's database.

## Important before selling/deploying

This is a functional starter project, not a fully audited production system. Before using it with a real institution:
- Add CSRF protection to every form (for example, Flask-WTF), rate limiting, account lockout, password reset and password change.
- Replace the development secret and the default admin password.
- Use HTTPS and a production WSGI server; never deploy Flask's development server or `debug=True`.
- Add database migrations (Flask-Migrate/Alembic), automated tests, backup/restore, logging and monitoring.
- Review authorization rules and privacy/data-retention requirements with the client.
- Add invoice/receipt PDF generation and fee liabilities/balance tracking if the client needs full accounting. The included fee module tracks payments, not billed amounts or outstanding balances.
- Configure database backups and test restore procedures.
- Add audit logs for sensitive changes and obtain client sign-off for requirements.

## Roles

- **Admin:** all modules, staff account management, archive/restore students, delete course/grade/payment records.
- **Teacher:** student create/edit, courses, attendance, grades and fee entries; cannot manage staff accounts or delete protected records.
