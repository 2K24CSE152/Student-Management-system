import os
import csv
import io
from datetime import date, datetime
from functools import wraps

from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, flash, abort, Response
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user, login_required, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-only-change-me-before-deployment")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///school.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {"pool_pre_ping": True}

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message_category = "warning"


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="teacher")
    active = db.Column(db.Boolean, nullable=False, default=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    admission_no = db.Column(db.String(40), unique=True, nullable=False)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120))
    phone = db.Column(db.String(40))
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(30))
    department = db.Column(db.String(100))
    class_name = db.Column(db.String(100))
    guardian_name = db.Column(db.String(120))
    guardian_phone = db.Column(db.String(40))
    address = db.Column(db.Text)
    enrollment_date = db.Column(db.Date, nullable=False, default=date.today)
    status = db.Column(db.String(20), nullable=False, default="Active")
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    department = db.Column(db.String(100))
    teacher_name = db.Column(db.String(120))
    credits = db.Column(db.Integer, nullable=False, default=3)
    description = db.Column(db.Text)


class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    attendance_date = db.Column(db.Date, nullable=False, default=date.today)
    status = db.Column(db.String(20), nullable=False)
    note = db.Column(db.String(250))
    student = db.relationship("Student", backref=db.backref("attendance_records", lazy=True))
    __table_args__ = (db.UniqueConstraint("student_id", "attendance_date", name="unique_student_attendance_day"),)


class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("course.id"), nullable=False)
    assessment = db.Column(db.String(120), nullable=False)
    marks_obtained = db.Column(db.Float, nullable=False)
    total_marks = db.Column(db.Float, nullable=False)
    recorded_on = db.Column(db.Date, nullable=False, default=date.today)
    student = db.relationship("Student", backref=db.backref("grades", lazy=True))
    course = db.relationship("Course", backref=db.backref("grades", lazy=True))

    @property
    def percentage(self):
        return round((self.marks_obtained / self.total_marks) * 100, 2) if self.total_marks else 0


class FeePayment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    payment_date = db.Column(db.Date, nullable=False, default=date.today)
    payment_method = db.Column(db.String(40), nullable=False, default="Cash")
    reference = db.Column(db.String(100))
    note = db.Column(db.String(250))
    student = db.relationship("Student", backref=db.backref("payments", lazy=True))


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if not current_user.active:
                logout_user()
                flash("This account is disabled. Contact an administrator.", "danger")
                return redirect(url_for("login"))
            if current_user.role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


@app.context_processor
def inject_globals():
    return {"today": date.today(), "app_name": "CampusFlow SMS"}


@app.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and user.active and user.check_password(password):
            login_user(user)
            flash(f"Welcome back, {user.full_name}.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    stats = {
        "students": Student.query.filter_by(status="Active").count(),
        "teachers": User.query.filter_by(role="teacher", active=True).count(),
        "courses": Course.query.count(),
        "attendance_today": Attendance.query.filter_by(attendance_date=date.today(), status="Present").count(),
        "fees_total": db.session.query(db.func.coalesce(db.func.sum(FeePayment.amount), 0)).scalar() or 0,
    }
    recent_students = Student.query.order_by(Student.created_at.desc()).limit(6).all()
    recent_payments = FeePayment.query.order_by(FeePayment.payment_date.desc(), FeePayment.id.desc()).limit(5).all()
    attendance_total = Attendance.query.filter_by(attendance_date=date.today()).count()
    present_today = stats["attendance_today"]
    stats["attendance_percent"] = round(present_today / attendance_total * 100) if attendance_total else 0
    return render_template("dashboard.html", stats=stats, recent_students=recent_students, recent_payments=recent_payments)


@app.route("/students")
@login_required
def students():
    q = request.args.get("q", "").strip()
    query = Student.query
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(
            Student.first_name.ilike(like), Student.last_name.ilike(like),
            Student.admission_no.ilike(like), Student.email.ilike(like),
            Student.department.ilike(like), Student.class_name.ilike(like)
        ))
    rows = query.order_by(Student.created_at.desc()).all()
    return render_template("students.html", students=rows, q=q)


@app.route("/students/new", methods=["GET", "POST"])
@roles_required("admin", "teacher")
def student_new():
    if request.method == "POST":
        admission_no = request.form.get("admission_no", "").strip()
        first_name = request.form.get("first_name", "").strip()
        last_name = request.form.get("last_name", "").strip()
        if not admission_no or not first_name or not last_name:
            flash("Admission number, first name and last name are required.", "danger")
        elif Student.query.filter_by(admission_no=admission_no).first():
            flash("That admission number already exists.", "danger")
        else:
            s = Student(
                admission_no=admission_no, first_name=first_name, last_name=last_name,
                email=request.form.get("email", "").strip() or None,
                phone=request.form.get("phone", "").strip() or None,
                date_of_birth=parse_date(request.form.get("date_of_birth")),
                gender=request.form.get("gender") or None,
                department=request.form.get("department", "").strip() or None,
                class_name=request.form.get("class_name", "").strip() or None,
                guardian_name=request.form.get("guardian_name", "").strip() or None,
                guardian_phone=request.form.get("guardian_phone", "").strip() or None,
                address=request.form.get("address", "").strip() or None,
                enrollment_date=parse_date(request.form.get("enrollment_date")) or date.today(),
                status=request.form.get("status") or "Active",
            )
            db.session.add(s)
            db.session.commit()
            flash("Student record created.", "success")
            return redirect(url_for("students"))
    return render_template("student_form.html", student=None)


@app.route("/students/<int:student_id>/edit", methods=["GET", "POST"])
@roles_required("admin", "teacher")
def student_edit(student_id):
    student = db.get_or_404(Student, student_id)
    if request.method == "POST":
        admission_no = request.form.get("admission_no", "").strip()
        duplicate = Student.query.filter(Student.admission_no == admission_no, Student.id != student.id).first()
        if not admission_no or not request.form.get("first_name", "").strip() or not request.form.get("last_name", "").strip():
            flash("Admission number, first name and last name are required.", "danger")
        elif duplicate:
            flash("That admission number is already assigned to another student.", "danger")
        else:
            student.admission_no = admission_no
            student.first_name = request.form.get("first_name", "").strip()
            student.last_name = request.form.get("last_name", "").strip()
            student.email = request.form.get("email", "").strip() or None
            student.phone = request.form.get("phone", "").strip() or None
            student.date_of_birth = parse_date(request.form.get("date_of_birth"))
            student.gender = request.form.get("gender") or None
            student.department = request.form.get("department", "").strip() or None
            student.class_name = request.form.get("class_name", "").strip() or None
            student.guardian_name = request.form.get("guardian_name", "").strip() or None
            student.guardian_phone = request.form.get("guardian_phone", "").strip() or None
            student.address = request.form.get("address", "").strip() or None
            student.enrollment_date = parse_date(request.form.get("enrollment_date")) or student.enrollment_date
            student.status = request.form.get("status") or "Active"
            db.session.commit()
            flash("Student record updated.", "success")
            return redirect(url_for("students"))
    return render_template("student_form.html", student=student)


@app.route("/students/<int:student_id>/archive", methods=["POST"])
@roles_required("admin")
def student_archive(student_id):
    student = db.get_or_404(Student, student_id)
    student.status = "Archived" if student.status == "Active" else "Active"
    db.session.commit()
    flash(f"{student.full_name}'s status is now {student.status.lower()}.", "success")
    return redirect(url_for("students"))


@app.route("/courses", methods=["GET", "POST"])
@roles_required("admin", "teacher")
def courses():
    if request.method == "POST":
        code = request.form.get("code", "").strip().upper()
        name = request.form.get("name", "").strip()
        if not code or not name:
            flash("Course code and name are required.", "danger")
        elif Course.query.filter_by(code=code).first():
            flash("Course code already exists.", "danger")
        else:
            course = Course(code=code, name=name,
                            department=request.form.get("department", "").strip() or None,
                            teacher_name=request.form.get("teacher_name", "").strip() or None,
                            credits=max(1, int_or(request.form.get("credits"), 3)),
                            description=request.form.get("description", "").strip() or None)
            db.session.add(course)
            db.session.commit()
            flash("Course added.", "success")
            return redirect(url_for("courses"))
    return render_template("courses.html", courses=Course.query.order_by(Course.name).all())


@app.route("/courses/<int:course_id>/delete", methods=["POST"])
@roles_required("admin")
def course_delete(course_id):
    course = db.get_or_404(Course, course_id)
    if Grade.query.filter_by(course_id=course.id).first():
        flash("This course has grade records and cannot be deleted. Keep it for reporting integrity.", "warning")
    else:
        db.session.delete(course)
        db.session.commit()
        flash("Course deleted.", "success")
    return redirect(url_for("courses"))


@app.route("/attendance", methods=["GET", "POST"])
@roles_required("admin", "teacher")
def attendance():
    selected_date = parse_date(request.values.get("attendance_date")) or date.today()
    if request.method == "POST":
        student_id = int_or(request.form.get("student_id"), 0)
        status = request.form.get("status")
        student = db.session.get(Student, student_id)
        if not student or status not in ("Present", "Absent", "Late", "Excused"):
            flash("Please select a valid student and attendance status.", "danger")
        else:
            record = Attendance.query.filter_by(student_id=student_id, attendance_date=selected_date).first()
            if record:
                record.status = status
                record.note = request.form.get("note", "").strip() or None
            else:
                db.session.add(Attendance(student_id=student_id, attendance_date=selected_date,
                                          status=status, note=request.form.get("note", "").strip() or None))
            db.session.commit()
            flash("Attendance saved.", "success")
            return redirect(url_for("attendance", attendance_date=selected_date.isoformat()))
    records = Attendance.query.filter_by(attendance_date=selected_date).join(Student).order_by(Student.first_name).all()
    return render_template("attendance.html", students=Student.query.filter_by(status="Active").order_by(Student.first_name).all(),
                           records=records, selected_date=selected_date)


@app.route("/grades", methods=["GET", "POST"])
@roles_required("admin", "teacher")
def grades():
    if request.method == "POST":
        student = db.session.get(Student, int_or(request.form.get("student_id"), 0))
        course = db.session.get(Course, int_or(request.form.get("course_id"), 0))
        assessment = request.form.get("assessment", "").strip()
        obtained = float_or(request.form.get("marks_obtained"), -1)
        total = float_or(request.form.get("total_marks"), 0)
        if not student or not course or not assessment or total <= 0 or obtained < 0 or obtained > total:
            flash("Check student, course, assessment and marks. Obtained marks must be between 0 and total.", "danger")
        else:
            db.session.add(Grade(student_id=student.id, course_id=course.id, assessment=assessment,
                                 marks_obtained=obtained, total_marks=total,
                                 recorded_on=parse_date(request.form.get("recorded_on")) or date.today()))
            db.session.commit()
            flash("Grade recorded.", "success")
            return redirect(url_for("grades"))
    rows = Grade.query.order_by(Grade.recorded_on.desc(), Grade.id.desc()).limit(200).all()
    return render_template("grades.html", grades=rows,
                           students=Student.query.filter_by(status="Active").order_by(Student.first_name).all(),
                           courses=Course.query.order_by(Course.name).all())


@app.route("/grades/<int:grade_id>/delete", methods=["POST"])
@roles_required("admin")
def grade_delete(grade_id):
    grade = db.get_or_404(Grade, grade_id)
    db.session.delete(grade)
    db.session.commit()
    flash("Grade record deleted.", "success")
    return redirect(url_for("grades"))


@app.route("/fees", methods=["GET", "POST"])
@roles_required("admin", "teacher")
def fees():
    if request.method == "POST":
        student = db.session.get(Student, int_or(request.form.get("student_id"), 0))
        amount = float_or(request.form.get("amount"), 0)
        if not student or amount <= 0:
            flash("Select a student and enter a payment amount greater than zero.", "danger")
        else:
            payment = FeePayment(student_id=student.id, amount=amount,
                                 payment_date=parse_date(request.form.get("payment_date")) or date.today(),
                                 payment_method=request.form.get("payment_method") or "Cash",
                                 reference=request.form.get("reference", "").strip() or None,
                                 note=request.form.get("note", "").strip() or None)
            db.session.add(payment)
            db.session.commit()
            flash("Payment recorded.", "success")
            return redirect(url_for("fees"))
    rows = FeePayment.query.order_by(FeePayment.payment_date.desc(), FeePayment.id.desc()).limit(200).all()
    total = db.session.query(db.func.coalesce(db.func.sum(FeePayment.amount), 0)).scalar() or 0
    return render_template("fees.html", payments=rows, students=Student.query.order_by(Student.first_name).all(), total=total)


@app.route("/fees/<int:payment_id>/delete", methods=["POST"])
@roles_required("admin")
def fee_delete(payment_id):
    payment = db.get_or_404(FeePayment, payment_id)
    db.session.delete(payment)
    db.session.commit()
    flash("Payment record deleted.", "success")
    return redirect(url_for("fees"))


@app.route("/reports/students.csv")
@roles_required("admin", "teacher")
def export_students():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Admission No", "First Name", "Last Name", "Email", "Phone", "Department", "Class", "Enrollment Date", "Status"])
    for s in Student.query.order_by(Student.admission_no).all():
        writer.writerow([s.admission_no, s.first_name, s.last_name, s.email or "", s.phone or "",
                         s.department or "", s.class_name or "", s.enrollment_date.isoformat(), s.status])
    return Response("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=students_report.csv"})


@app.route("/users", methods=["GET", "POST"])
@roles_required("admin")
def users():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "teacher")
        if not username or not full_name or len(password) < 10 or role not in ("admin", "teacher"):
            flash("Enter a username, full name, valid role and password of at least 10 characters.", "danger")
        elif User.query.filter_by(username=username).first():
            flash("Username already exists.", "danger")
        else:
            user = User(username=username, full_name=full_name, role=role)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            flash("Account created.", "success")
            return redirect(url_for("users"))
    return render_template("users.html", users=User.query.order_by(User.full_name).all())


@app.route("/users/<int:user_id>/toggle", methods=["POST"])
@roles_required("admin")
def user_toggle(user_id):
    user = db.get_or_404(User, user_id)
    if user.id == current_user.id:
        flash("You cannot disable your own account.", "warning")
    else:
        user.active = not user.active
        db.session.commit()
        flash("Account status updated.", "success")
    return redirect(url_for("users"))


@app.errorhandler(403)
def forbidden(_error):
    return render_template("error.html", code=403, message="You do not have permission to access this page."), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="The requested record or page was not found."), 404


def parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def int_or(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def float_or(value, default):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def init_db():
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username="admin").first():
            admin = User(username="admin", full_name="System Administrator", role="admin")
            admin.set_password(os.getenv("INITIAL_ADMIN_PASSWORD", "ChangeMe123!"))
            db.session.add(admin)
            db.session.commit()
            print("Created default admin account: admin / ChangeMe123! (change it immediately)")


if __name__ == "__main__":
    init_db()
    app.run(debug=os.getenv("FLASK_DEBUG", "0") == "1")
