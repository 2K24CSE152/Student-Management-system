(() => {
  const root = document.documentElement;
  const saved = localStorage.getItem("campusflow-theme");
  if (saved) root.dataset.theme = saved;
  const toggle = document.getElementById("themeToggle");
  if (toggle) toggle.addEventListener("click", () => {
    const next = root.dataset.theme === "dark" ? "light" : "dark";
    root.dataset.theme = next;
    localStorage.setItem("campusflow-theme", next);
  });
  const menu = document.getElementById("mobileMenu");
  const sidebar = document.getElementById("sidebar");
  if (menu && sidebar) menu.addEventListener("click", () => sidebar.classList.toggle("sidebar-open"));
  document.querySelectorAll(".alert").forEach(alert => {
    window.setTimeout(() => {
      if (window.bootstrap && !alert.classList.contains("show")) return;
      if (window.bootstrap) bootstrap.Alert.getOrCreateInstance(alert).close();
    }, 6500);
  });
})();
